package com.springboot.Restapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NimapInfotechSpringbootTaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
